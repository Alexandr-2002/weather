package com.example.weather

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.weather.ui.ListScren
import com.example.weather.ui.PushScreen
import com.example.weather.ui.theme.WeatherTheme
import com.example.weather.ui.window.SearchScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            WeatherTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    RallyApp()
                }
            }
        }
    }
}

@Composable
fun RallyApp() {
    val navController = rememberNavController()
    val bottomItems = listOf("Сегодня","Завтра","Неделя")

    Scaffold(
        bottomBar = {
            BottomNavigation() {
                bottomItems.forEach{ screen ->
                    BottomNavigationItem(
                        selected = false,
                        onClick = {
                            navController.navigate(screen)
                        },
                        label = { Text(text = screen)},
                        icon = {

                        })
                }
            }
        }
    ) {
        NavHost(navController,"Сегодня"){
            composable("Сегодня")
            { ListScren(navController) }
            composable("Завтра")
            { SearchScreen() }
            composable("Неделя")
            { PushScreen() }
        }
    }
}
